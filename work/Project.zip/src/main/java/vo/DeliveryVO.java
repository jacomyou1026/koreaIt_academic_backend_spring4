package vo;

public class DeliveryVO {
	private int deliveryNum,deliveryTel1,deliveryTel2,deliveryTel3,deliveryPostcode;
	private String deliveryName, deliveryAddress1,deliveryAddress2;
	
	
	
	
	public int getDeliveryNum() {
		return deliveryNum;
	}
	public void setDeliveryNum(int deliveryNum) {
		this.deliveryNum = deliveryNum;
	}
	public int getDeliveryTel1() {
		return deliveryTel1;
	}
	public void setDeliveryTel1(int deliveryTel1) {
		this.deliveryTel1 = deliveryTel1;
	}
	public int getDeliveryTel2() {
		return deliveryTel2;
	}
	public void setDeliveryTel2(int deliveryTel2) {
		this.deliveryTel2 = deliveryTel2;
	}
	public int getDeliveryTel3() {
		return deliveryTel3;
	}
	public void setDeliveryTel3(int deliveryTel3) {
		this.deliveryTel3 = deliveryTel3;
	}
	public int getDeliveryPostcode() {
		return deliveryPostcode;
	}
	public void setDeliveryPostcode(int deliveryPostcode) {
		this.deliveryPostcode = deliveryPostcode;
	}
	
	public String getDeliveryName() {
		return deliveryName;
	}
	public void setDeliveryName(String deliveryName) {
		this.deliveryName = deliveryName;
	}
	public String getDeliveryAddress1() {
		return deliveryAddress1;
	}
	public void setDeliveryAddress1(String deliveryAddress1) {
		this.deliveryAddress1 = deliveryAddress1;
	}
	public String getDeliveryAddress2() {
		return deliveryAddress2;
	}
	public void setDeliveryAddress2(String deliveryAddress2) {
		this.deliveryAddress2 = deliveryAddress2;
	}
	
	
}
