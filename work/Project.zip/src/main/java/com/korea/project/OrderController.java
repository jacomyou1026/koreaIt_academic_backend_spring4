package com.korea.project;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import dao.BookDAO;
import dao.BookPurchaseDAO;
import dao.UserDAO;
import vo.BookVO;
import vo.DeliveryVO;
import vo.OrderPageDTO;
import vo.OrderVO;
import vo.UserVO;

@Controller
public class OrderController {
	@Autowired // 자동주입 : 스프링에서 제공하는 클래스에 대해 자동으로 객체를 만들어주는 기능
	// 이 기능을 사용하려면 servlet-context.xml에 <context:annotation-config/>속성을 추가해둬야 한다
	HttpServletRequest request; // Autowired를 통해 자동으로 객체생성이 된다

	@Autowired
	ServletContext application; // 현재프로젝트의 정보를 저장하고 있는 클래스

	static final String WEB_PATH = "/WEB-INF/views/shop&purchase/";

	UserDAO user_dao;

	public void setUser_dao(UserDAO user_dao) {
		this.user_dao = user_dao;
	}

	BookDAO book_dao;

	public void setBook_dao(BookDAO book_dao) {
		this.book_dao = book_dao;
	}

	BookPurchaseDAO book_purchase_dao;

	public void setBook_purchase_dao(BookPurchaseDAO book_purchase_dao) {
		this.book_purchase_dao = book_purchase_dao;
	}

	@RequestMapping(value = "/purchase_book_one.do")
	public String bookOne(Model model, OrderVO vo) { // 유저 정보 UserVO list1 = user_dao.selectOne();
		return WEB_PATH + "payment.jsp";
	}

	@RequestMapping(value = "/purchase.do")
	public String list(Model model, OrderVO vo) {
		// 유저 정보
		UserVO list1 = user_dao.selectOne();

		// 책정보
		List<BookVO> list2 = book_dao.selectlist();

		// 책구매정보(책정보 + 책 구매정보)
		List<OrderVO> list3 = book_purchase_dao.selectlist();

		// 책 출고예정날짜
		List<String> releasedDate = book_purchase_dao.regSelect();

		// 총합
		int totalPrice = book_purchase_dao.totalpriceSelect();

		int finalprice = 0;
		int savePoint =0;
		// 총합이 shoppoint보다 클때 전체shoppoint 쓰기
		if (totalPrice > list1.getShopPoint()) {
			finalprice = (totalPrice - list1.getShopPoint());
			//적립
			savePoint=(int) (finalprice*0.1);
		} else {
			// shoppoint가 총합보다 클 경우
			finalprice=0;
		}
		
		// 총 주문 개수
		int totalcnt = book_purchase_dao.totalcnt();

		// 적립
		model.addAttribute("user", list1);
		model.addAttribute("book", list2);
		model.addAttribute("order", list3);

		model.addAttribute("totalcnt", totalcnt);
		model.addAttribute("totalPrice", totalPrice);
		model.addAttribute("finalprice", finalprice);
		model.addAttribute("released", releasedDate);
		model.addAttribute("savePoint", savePoint);

		return WEB_PATH + "payment.jsp";

	}

	// 배송지 변경 후 주문 완료 화면으로 이동
	@RequestMapping("update_success_payment.do")
	public String update_success_payment(Model model, DeliveryVO vo) {

		// BOOK_PURCHASE에 있는 deliveryNum의 default값을 0으로 줌
		// BOOK_PURCHASE에 있는 deliveryNum update함으로써 0보다 큰 수들은 배송지 변경 후 주문으로 인식
		// deliverysep를 1증가
		book_purchase_dao.updatedeliverysep();
		UserVO list1 = user_dao.selectOne();
		// 총 주문 상품
		int totalcnt = book_purchase_dao.totalcnt();

		book_purchase_dao.insertdelivery(vo);
		
		// 적립
		int totalPrice = book_purchase_dao.totalpriceSelect();
		int savePoint=0;
		int finalprice = 0;
		if (totalPrice > list1.getShopPoint()) {
			finalprice = (totalPrice - list1.getShopPoint());
			savePoint=(int) (finalprice*0.1);
		} else {
			// shoppoint가 총합보다 클 경우
			finalprice=0;
		}
		
		
	//	int savePoint = book_purchase_dao.savepoint();
		

		model.addAttribute("totalcnt", totalcnt);
		model.addAttribute("savePoint", savePoint);

		return WEB_PATH + "success_payment.jsp";

	}

	// 주문완료화면으로 이동(주문 완료 페이지)
	@RequestMapping("/success_payment.do")
	public String success_payment(Model model) {
		List<OrderVO> list3 = book_purchase_dao.selectlist();
		model.addAttribute("order", list3);
		UserVO list1 = user_dao.selectOne();
		// 적립         
		int savePoint =0;
		int totalPrice = book_purchase_dao.totalpriceSelect();
		
		if(totalPrice > list1.getShopPoint()) {
			
			//savePoint = book_purchase_dao.savepoint();
			
		}else {
			
			savePoint = 0;
		}
		
		// 총 주문 개수
		int totalcnt = book_purchase_dao.totalcnt();
		

		model.addAttribute("totalcnt", totalcnt);
		model.addAttribute("savePoint", savePoint);

		return WEB_PATH + "success_payment.jsp";
	}

	// 주문 상세페이지
	@RequestMapping("/detail_page.do")
	public String content_page(Model model) {
		// 유저 정보
		UserVO list1 = user_dao.selectOne();
		List<OrderVO> list3 = book_purchase_dao.selectlist();

		int totalPrice = book_purchase_dao.totalpriceSelect();

		// 총 주문 개수s
		int totalcnt = book_purchase_dao.totalcnt();

		// 돈-최종결제금액
		int finalprice = 0;
		int savePoint =0;
		// 총합이 shoppoint보다 클때 전체shoppoint 쓰기
		if (totalPrice > list1.getShopPoint()) {
			finalprice = (totalPrice - list1.getShopPoint());
			//적립
			savePoint=(int) (finalprice*0.1);
		} else {
			// shoppoint가 총합보다 클 경우
			finalprice=0;
		}
		
		

		model.addAttribute("list1", list1);
		model.addAttribute("order", list3);
		

		model.addAttribute("totalcnt", totalcnt);
		model.addAttribute("totalPrice", totalPrice);
		model.addAttribute("finalprice", finalprice);

		return WEB_PATH + "detail_page.jsp";
	}

	@RequestMapping("chargePoint.do")
	@ResponseBody
	public String charge(int amount) {
		System.out.println(amount + "데이터 받음");
		int res = UserDAO.insert_pay(amount);

		String str = "no";// 안됨

		if (res == 1) {
			str = "yes";// 됨
		}

		return str;
	}
	
	
	// 메인화면으로 이동(주문환료후)
	// deliverySep 0으로 변경
	// 적립포인트 더하기
	
	// 장바구니 없애기
	
	// db_purchase_table 없애기
	// purcahse있는 데이터 다른 테이블로 update
	@RequestMapping("/main.do")
	public String main( OrderVO vo) {

		// 기존배송지로 초기화 - 0으로 바꿈
		book_purchase_dao.initdeliverysep();

		// 유저 정보
		UserVO list1 = user_dao.selectOne();

		// 기존 돈
		list1.getMoney();

		
		
		//장바구니 제거(purchase테이블 삭제 후 실행가능)- 자식 
		/*
		 * String[] shopnums=request.getParameterValues("shopnum"); if(shopnums !=null)
		 * { for (int i = 0; i < shopnums.length; i++) {
		 * System.out.println(shopnums[i]+"번호"); int delshoppingCart =
		 * book_purchase_dao.delshoppingCart(vo); } }
		 */
		

		
		
		int totalPrice = book_purchase_dao.totalpriceSelect();
		// 돈-최종결제금액
		int finalprice = 0;
		// 총합이 shoppoint보다 클때 전체shoppoint 쓰기
		int savePoint= 0;
		if (totalPrice > list1.getShopPoint()) {
			finalprice = (totalPrice - list1.getShopPoint());
			// 적립예종 포인트
			savePoint=(int) (finalprice*0.1);
			System.out.println(savePoint + "적립예정 업데이트");
			// 적립예정 update
			int update_shopping_point_res = book_purchase_dao.UpdateShoppingPoing(savePoint);
		} else {
			savePoint = 0;
			//사용자 포인트 - 상품금액 업데이트
			int bigshop = (list1.getShopPoint()-totalPrice);
			vo.setBigshop(bigshop);
			int bigshoppingpointt = book_purchase_dao.bigshoppingpoint(vo);
			
		}
		
		System.out.println(finalprice+"최종결제금액");
		
		int update_money = list1.getMoney()-finalprice;

		int update_money_res = book_purchase_dao.UpdateMoney(update_money);

		return WEB_PATH + "main.jsp";
	}
	
	

//	장바구니로 이동
	@RequestMapping("/goshopping.do")
	public String goshopping(OrderVO vo) {
		
		// purchase정보 삭제
		int delpurchase = book_purchase_dao.delgoshoppurchse(vo);
		
		System.out.println(delpurchase);
		
		return "redirect:shoppingCart.do";
	}

}