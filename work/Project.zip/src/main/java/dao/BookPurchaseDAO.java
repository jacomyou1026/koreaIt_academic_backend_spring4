package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.DeliveryVO;
import vo.OrderVO;

public class BookPurchaseDAO {
	SqlSession sqlSession;
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
//	book table + purchase table (join)
	public List<OrderVO> selectlist() {
		List<OrderVO> list= sqlSession.selectList("parchase.order_list");
		
		return list;

	}
	
	//출고 날짜
	public List<String>regSelect() {
		List<String> relase =sqlSession.selectList("parchase.releaseBook");
		return relase; 
				
	}
	

	//총 합(책 전체)
	public int totalpriceSelect() {
		int  totalprice = sqlSession.selectOne("parchase.totalprice");
		return totalprice;
	}
	
	
	//총 주문 개수 
	public int totalcnt() {
		int cnt= sqlSession.selectOne("parchase.totalcnt");
		return cnt;
	}

	
	//변경된 배송지 추가
	public int insertdelivery(DeliveryVO vo) {
		int delivery = sqlSession.insert("parchase.isnertdelivery",vo);
		return delivery;
	}
	
	//배송지 변경된 것이지 구분
	public int updatedeliverysep() {
		int updateDeliveryNum = sqlSession.update("parchase.updatedeliverysep");
		return updateDeliveryNum;
	}
	
	//기존배송지와 이외 배송지 구분을 초기화
	public int initdeliverysep() {
		int initdeliverysep = sqlSession.update("parchase.initdeliverysep");
		return initdeliverysep;
	}
	
	//적립
	public int UpdateShoppingPoing(int savePoint) {
		int UpdateShoppingPoing = sqlSession.update("parchase.UpdateShoppingPoing",savePoint);
		return UpdateShoppingPoing;
	}
	
	//money_update
	public int UpdateMoney(int update_money) {
		int UpdateMoney = sqlSession.update("parchase.UpdateMoney",update_money);
		return UpdateMoney;
	}
	
	//바로구매 1개 구매
	public OrderVO bookone(OrderVO vo) {
		OrderVO bookone= sqlSession.selectOne("parchase.bookone",vo);
		return bookone;
	}
	
	
	//장바구니로 이동시 purchasetable 삭제
	public int delgoshoppurchse(OrderVO vo) {
		int delgoshoppurchse= sqlSession.delete("parchase.delgoshoppurchse",vo);
		
		return delgoshoppurchse;
	}
	
	
	//결제하기 후 체크된 장바구니 삭제
	public int delshoppingCart(OrderVO vo) {
		int delshoppingCart= sqlSession.delete("parchase.delshoppingCart",vo);
		
		return delshoppingCart;
	}
	
	//사용자 포인트 - 상품금액 업데이트(사용자 포인트가 더 클경우)
	public int bigshoppingpoint(OrderVO vo) {
		int delshoppingCart= sqlSession.update("parchase.bigshoppingpoint",vo);
		
		return delshoppingCart;
	}

	
}
