package dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.BookVO;

public class BookDAO {
	SqlSession sqlSession;
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	public List<BookVO> selectlist() {
		List<BookVO> list= sqlSession.selectList("b.book_list");
		return list;

	}
	
}
